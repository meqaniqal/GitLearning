# GitLearning App
## An app just demonstrating the use of git in XCode

## Installation:
Double click the XCode project in the unzipped folder to see the project, and play with its demonstration functionality.
You can click the ![x repo icon](ReadmeImages/repoicon.png) to view the git branches and see the revision histories for the 2 branches "main" and "sheet"

## License:
This project is licence unknown, as it was not written by me and it is just the code for a tutorial from a Udemy course by Gwinyai Nyatsoka on swift IOS programming.
