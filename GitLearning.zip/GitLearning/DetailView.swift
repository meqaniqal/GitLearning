//
//  DetailView.swift
//  GitLearning
//
//  Created by Sheldon Lawrence on 3/12/25.
//

import SwiftUI

struct DetailView: View {
    var body: some View {
        Text("An app to learn git.")
    }
}

#Preview {
    DetailView()
}
